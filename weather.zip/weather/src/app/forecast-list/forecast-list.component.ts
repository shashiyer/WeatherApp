import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forecast-list',
  templateUrl: './forecast-list.component.html',
  styleUrls: ['./forecast-list.component.css']
})
export class ForecastListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
