import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class WeatherService {

  static url = 'http://api.openweathermap.org/data/2.5';
  static Appid = '5a4b2d457ecbef9eb2a71e480b947604'
  static icon_url =  'https://raw.githubusercontent.com/udacity/Sunshine-Version-2/sunshine_master/app/src/main/res/drawable-hdpi/';
  private currentConditions = [];

  constructor(private http : HttpClient) { }

  loadCurrentConditions(zipcode : string) : Observable<any>
  {
    return this.http.get('{$weather}')
  }
}
