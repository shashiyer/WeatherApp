
import { ZipcodeActions, ZipCodeActionTypes } from '../actions/zipcode.actions';

export interface ZipcodeState
{
    zipcodes : Array<string>
}

export const intialState : ZipcodeState = 
{
    zipcodes : []
};

export function ZipcodeReducer(state = intialState, action : ZipcodeActions) : ZipcodeState
{
    switch(action.type)
    {
        case ZipCodeActionTypes.AddZipcode: 
        return {...state, zipcodes : [...state.zipcodes, action.zipcode]};

        case ZipCodeActionTypes.RemoveZipcode:
            return{...state, zipcodes : state.zipcodes.filter(item => item !== action.zipcode)};

        default: 
        return state;
    }
}