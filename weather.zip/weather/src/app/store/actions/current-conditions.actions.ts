import { Action } from '@ngrx/store';

export enum CurrentConditionsActionTypes
{
    CurrentConditionsLoaded = '[CurrentConditions] CurrentCondiitonsLoaded',
    CurrentConditionsFailed = '[CurrentConditions] CurrentConditionsFailed'
}

export class CurrentCondiitonsLoaded implements Action
{
    readonly type = CurrentConditionsActionTypes.CurrentConditionsLoaded;

    constructor(public zipcode : string, public conditions : any){}
}

export class CurrentCondiitonsFailed implements Action
{
    readonly type = CurrentConditionsActionTypes.CurrentConditionsFailed;

    constructor(public zipcode : string, public conditions : any){}
}

export type CurrentConditionsActions = CurrentCondiitonsLoaded | CurrentCondiitonsFailed;
    