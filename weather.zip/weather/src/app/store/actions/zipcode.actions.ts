import { Action } from '@ngrx/store';

export enum ZipCodeActionTypes
{
    AddZipcode = '[Zipcode] Add Zipcode',
    RemoveZipcode = '[Zipcode] Remove Zipcode'
}

export class AddZipcode implements Action
{
    readonly type = ZipCodeActionTypes.AddZipcode;
    constructor( public zipcode : string){}
}

export class RemoveZipcode implements Action
{
    readonly type = ZipCodeActionTypes.RemoveZipcode;
    constructor( public zipcode : string ){}
}

export type ZipcodeActions = AddZipcode | RemoveZipcode; 