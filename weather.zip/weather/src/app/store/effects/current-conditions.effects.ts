import { Injectable } from "@angular/core";
import {  } from "@ngrx/";
@Injectable()

export class CurrentConditionsEffects
{
    @Effect()

}