import { ForecastState, ForecastReducer } from './reducers/forecast.reducers';
import { ZipcodeState, ZipcodeReducer } from './reducers/zipcode.reducers';
import { CurrentConditionsState, currentConditionsReducer } from './reducers/current-conditions.reducers';
import { RouterReducerState, routerReducer } from "@ngrx/router-store";
import { ActionReducer, ActionReducerMap, MetaReducer, createSelector } from '@ngrx/store';
import { environment } from 'src/environments/environment.prod';

export interface State
{
    zipcodes : ZipcodeState,
    currentConditions : CurrentConditionsState,
    router : RouterReducerState,
    forecast : ForecastState
};

export const reducers : ActionReducerMap<State> = 
{
    zipcodes : ZipcodeReducer,
    currentConditions : currentConditionsReducer,
    router : routerReducer,
    forecast : ForecastReducer,
};

export const metaReducers : MetaReducer<State>[] = !environment.production ? [] : [];    

export const selectZipcodeState = (state : State) => state.zipcodes;

export const selectZipcodeList = createSelector(selectZipcodeState, (state:ZipcodeState) => state.zipcodes);

export const selectCurrentConditionsState = (state : State) => state.currentConditions;

export const selectCurrentConditionsList = createSelector(selectCurrentConditionsState, (state:CurrentConditionsState) => state.currentConditions);

export const selectForecastState = (state:State) => state.forecast;

export const    selectForecastList = createSelector(selectForecastState, (state : ForecastState) => state.forecast);