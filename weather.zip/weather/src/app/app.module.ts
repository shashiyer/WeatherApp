import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ZipcodeComponent } from './zipcode/zipcode.component';
import { CurrentWeatherComponent } from './current-weather/current-weather.component';
import { ForecastListComponent } from './forecast-list/forecast-list.component';
import { MainPageComponent } from './main-page/main-page.component';
import { HttpClientModule } from "@angular/common/http";
import { StoreModule } from '@ngrx/store';
import { reducers, metaReducers } from './store/app.states';
import { StoreDevtoolsModule } from "@ngrx/store-devtools";
import { environment } from "../environments/environment";
import { StoreRouterConnectingModule } from "@ngrx/router-store";
import { RouterModule } from "@angular/router";
import { WeatherService } from "./services/weather.service";
import { LocationService } from "./services/location.service";

@NgModule({
  declarations: [
    AppComponent,
    ZipcodeComponent,
    CurrentWeatherComponent,
    ForecastListComponent,
    MainPageComponent,
    WeatherService,
    LocationService
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, 
    FormsModule,
    HttpClientModule,
    RouterModule,
    AppRoutingModule,
    StoreModule.forRoot(reducers, {metaReducers}),
    !environment.production ? StoreDevtoolsModule.instrument() : [],
    StoreRouterConnectingModule.forRoot({stateKey : 'router'})
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
