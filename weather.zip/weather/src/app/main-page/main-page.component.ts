import { Component, OnInit } from '@angular/core';
import { Store } from "@ngrx/store";
import { WeatherService } from '../weather.service';
import { AddZipcode, RemoveZipcode } from '../store/actions/zipcode.actions';

@Component({
  selector: 'app-main-page',
  templateUrl: './main-page.component.html',
  styleUrls: ['./main-page.component.css']
})

export class MainPageComponent implements OnInit {

zipcodes : Array<string>;

currentCondtions : Map<string, any>;

  constructor(private store : Store<State>, public weatherService : WeatherService) {
    store.select(selectZipcodeList)
    .subscribe(zips => this.zipcodes = zips);

    store.select(selectCurrentConditions)
    .subscribe(conditions => this.currentCondtions = conditions);
   }

   addLocation(zipcode : string)
   {
      this.store.dispatch(new AddZipcode(zipcode));    
   }

   removeZip(zip : string)
   {
      this.store.dispatch(new RemoveZipcode(zip));
   }

  ngOnInit() {
  }

}
