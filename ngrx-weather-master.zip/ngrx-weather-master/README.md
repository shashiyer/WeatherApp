# ngrx-weather
An example of how to use Ngrx on a simple Angular app
